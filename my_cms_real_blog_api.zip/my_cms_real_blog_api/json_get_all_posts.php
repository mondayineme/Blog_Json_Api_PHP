<?php
    //database constants
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PASS', '');
	define('DB_NAME', 'techbarik');
	
	//connecting to database and getting the connection object
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    //Checking if any error occured while connecting
	if (mysqli_connect_errno()) {
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		die();
	}
	
	//creating a query
	$stmt = $conn->prepare("SELECT post_id, post_title, post_detail, post_image, post_date, post_author, post_views FROM posts;");
	
	//executing the query 
    $stmt->execute();
    
    //binding results to the query 
    $stmt->bind_result($post_id, $post_title, $post_detail, $post_image, $post_date, $post_author, $post_views);
    
    // $stmt->execute([
    //     ':status' => 'Published'
    // ]);
	
	$posts = array(); 
	
	//traversing through all the result 
	while($stmt->fetch()){
		$temp = array();
		$temp['post_id'] = $post_id; 
		$temp['post_title'] = $post_title; 
		$temp['post_detail'] = $post_detail; 
		$temp['post_image'] = $post_image; 
		$temp['post_date'] = $post_date; 
        $temp['post_author'] = $post_author;
        $temp['post_views'] = $post_views;  
		array_push($posts, $temp);
    }
    
    //displaying the result in json format 
	echo json_encode($posts);
  ?>